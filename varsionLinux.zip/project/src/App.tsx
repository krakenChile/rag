import React, { useState, useCallback } from 'react';
import * as tf from '@tensorflow/tfjs';
import { Brain, Loader2, FileUp, Link } from 'lucide-react';
import * as pdfjsLib from 'pdfjs-dist';

// Configurar el worker de PDF.js
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

type InputType = 'text' | 'file' | 'url';

// Función para agregar proxy CORS a la URL
const addCorsProxy = (url: string): string => {
  return `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
};

function App() {
  const [inputType, setInputType] = useState<InputType>('text');
  const [inputText, setInputText] = useState('');
  const [inputUrl, setInputUrl] = useState('');
  const [embeddings, setEmbeddings] = useState<number[] | null>(null);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isValidUrl = (urlString: string): boolean => {
    try {
      const url = new URL(urlString);
      return url.protocol === 'http:' || url.protocol === 'https:';
    } catch {
      return false;
    }
  };

  const processUrl = async (url: string) => {
    if (!isValidUrl(url)) {
      setError('URL inválida. Por favor, ingrese una URL completa que comience con http:// o https://');
      return;
    }

    setProcessing(true);
    setError(null);
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000);

      const proxyUrl = addCorsProxy(url);
      const response = await fetch(proxyUrl, {
        signal: controller.signal,
        headers: {
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,text/plain;q=0.8',
          'User-Agent': 'Mozilla/5.0 (compatible; TextExtractor/1.0)'
        }
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error('Error al acceder a la URL');
      }

      const html = await response.text();
      const text = html
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
        .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
        .replace(/<[^>]+>/g, ' ')
        .replace(/&nbsp;/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();

      if (!text) {
        throw new Error('No se pudo extraer texto de la URL proporcionada');
      }

      setInputText(text);
    } catch (err) {
      if (err instanceof Error) {
        if (err.name === 'AbortError') {
          setError('La URL está tardando demasiado en responder. Por favor, intente con otra URL.');
        } else if (err.message.includes('Failed to fetch')) {
          setError('No se pudo acceder a la URL. Verifique que la página permita acceso externo.');
        } else {
          setError(err.message || 'Error al procesar la URL. Por favor, verifique la URL e intente nuevamente.');
        }
      } else {
        setError('Error al procesar la URL. Por favor, verifique la URL e intente nuevamente.');
      }
      console.error('Error processing URL:', err);
    }
    setProcessing(false);
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setProcessing(true);
    setError(null);
    try {
      if (file.type === 'application/pdf') {
        const arrayBuffer = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        const page = await pdf.getPage(1);
        const textContent = await page.getTextContent();
        const text = textContent.items.map((item: any) => item.str).join(' ');
        setInputText(text);
      } else {
        throw new Error('Formato de archivo no soportado. Por favor, use archivos PDF.');
      }
    } catch (err) {
      setError('Error al procesar el archivo. Por favor, intente con otro archivo PDF.');
      console.error('Error processing file:', err);
    }
    setProcessing(false);
  };

  const generateEmbeddings = useCallback(async () => {
    if (!inputText.trim()) return;

    setProcessing(true);
    setError(null);
    try {
      const words = inputText.toLowerCase().split(/\s+/);
      const wordSet = new Set(words);
      const uniqueWords = Array.from(wordSet);
      
      const frequencies = words.reduce((acc: number[], word) => {
        const index = uniqueWords.indexOf(word);
        acc[index] = (acc[index] || 0) + 1;
        return acc;
      }, new Array(uniqueWords.length).fill(0));
      
      const tensor = tf.tensor1d(frequencies);
      const normalized = tf.div(tensor, tf.sum(tensor));
      
      const embeddingArray = Array.from(await normalized.data());
      setEmbeddings(embeddingArray);
      
      tensor.dispose();
      normalized.dispose();
    } catch (error) {
      setError('Error al generar embeddings. Por favor, intente nuevamente.');
      console.error('Error al generar embeddings:', error);
    }
    setProcessing(false);
  }, [inputText]);

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center gap-3 mb-6">
            <Brain className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-800">
              Generador de Embeddings
            </h1>
          </div>

          <div className="mb-6">
            <div className="flex gap-4 mb-4">
              <button
                onClick={() => setInputType('text')}
                className={`flex-1 py-2 px-4 rounded-md ${
                  inputType === 'text'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700'
                }`}
              >
                Texto
              </button>
              <button
                onClick={() => setInputType('file')}
                className={`flex-1 py-2 px-4 rounded-md ${
                  inputType === 'file'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700'
                }`}
              >
                Archivo
              </button>
              <button
                onClick={() => setInputType('url')}
                className={`flex-1 py-2 px-4 rounded-md ${
                  inputType === 'url'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700'
                }`}
              >
                URL
              </button>
            </div>

            {inputType === 'text' && (
              <div>
                <label
                  htmlFor="text-input"
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  Ingresa el texto para generar embeddings
                </label>
                <textarea
                  id="text-input"
                  className="w-full h-32 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Escribe o pega tu texto aquí..."
                />
              </div>
            )}

            {inputType === 'file' && (
              <div>
                <label
                  htmlFor="file-input"
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  Sube un archivo PDF
                </label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                  <div className="space-y-1 text-center">
                    <FileUp className="mx-auto h-12 w-12 text-gray-400" />
                    <div className="flex text-sm text-gray-600">
                      <label
                        htmlFor="file-upload"
                        className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500"
                      >
                        <span>Sube un archivo</span>
                        <input
                          id="file-upload"
                          name="file-upload"
                          type="file"
                          className="sr-only"
                          accept=".pdf"
                          onChange={handleFileUpload}
                        />
                      </label>
                      <p className="pl-1">o arrastra y suelta</p>
                    </div>
                    <p className="text-xs text-gray-500">PDF hasta 10MB</p>
                  </div>
                </div>
              </div>
            )}

            {inputType === 'url' && (
              <div>
                <label
                  htmlFor="url-input"
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  Ingresa la URL de la página web
                </label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    id="url-input"
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    value={inputUrl}
                    onChange={(e) => setInputUrl(e.target.value)}
                    placeholder="https://ejemplo.com"
                  />
                  <button
                    onClick={() => processUrl(inputUrl)}
                    disabled={!inputUrl.trim() || processing}
                    className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:bg-blue-300 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
                  >
                    <Link className="h-4 w-4" />
                    Procesar
                  </button>
                </div>
              </div>
            )}
          </div>

          {error && (
            <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
              <p className="text-red-600">{error}</p>
            </div>
          )}

          <button
            onClick={generateEmbeddings}
            disabled={processing || !inputText.trim()}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:bg-blue-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
          >
            {processing && <Loader2 className="h-4 w-4 animate-spin" />}
            {processing ? 'Procesando...' : 'Generar Embeddings'}
          </button>

          {embeddings && (
            <div className="mt-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-2">
                Resultados
              </h2>
              <div className="bg-gray-50 p-4 rounded-md">
                <p className="text-sm text-gray-600 mb-2">
                  Dimensiones del vector: {embeddings.length}
                </p>
                <p className="text-sm text-gray-600 mb-2">
                  Primeros 5 valores del vector:
                </p>
                <pre className="bg-gray-100 p-2 rounded text-sm overflow-x-auto">
                  {JSON.stringify(embeddings.slice(0, 5), null, 2)}
                </pre>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;